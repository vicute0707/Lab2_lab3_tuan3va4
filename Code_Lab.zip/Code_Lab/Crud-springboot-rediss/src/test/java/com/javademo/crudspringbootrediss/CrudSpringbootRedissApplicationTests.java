package com.javademo.crudspringbootrediss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringbootRedissApplicationTests {

    @Test
    void contextLoads() {
    }

}
